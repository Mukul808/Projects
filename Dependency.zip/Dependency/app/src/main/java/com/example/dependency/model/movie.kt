package com.example.dependency.model

data class Movie(
    val title: String,
    val director: String,
    val genre: String,
    val releaseYear: Int,
    val description: String? = null  // Optional, with default null
)