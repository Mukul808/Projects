package com.example.dependency

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dependency.adapter.MovieAdapter
import com.example.dependency.viewmodel.MovieViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val movieViewModel: MovieViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.movieRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            movieViewModel.movies.collectLatest { movies ->
                if (movies.isNotEmpty()) {
                    recyclerView.adapter = MovieAdapter(movies) { selectedMovie ->
                        // Open DetailActivity with selected movie info
                        val intent = Intent(this@MainActivity, DetailActivity::class.java).apply {
                            putExtra("title", selectedMovie.title)
                            putExtra("director", selectedMovie.director)
                            putExtra("genre", selectedMovie.genre)
                            putExtra("year", selectedMovie.releaseYear)
                            putExtra("description", selectedMovie.description)
                        }
                        startActivity(intent)
                    }
                }
            }
        }

        lifecycleScope.launch {
            movieViewModel.error.collectLatest { errorMsg ->
                errorMsg?.let {
                    Toast.makeText(this@MainActivity, it, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}