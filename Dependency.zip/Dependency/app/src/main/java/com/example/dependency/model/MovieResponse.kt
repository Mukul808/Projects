package com.example.dependency.model

data class MovieResponse(
    val entities: List<Movie>  // matches the JSON key exactly
)