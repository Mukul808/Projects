package com.example.dependency

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val title = intent.getStringExtra("title")
        val director = intent.getStringExtra("director")
        val genre = intent.getStringExtra("genre")
        val year = intent.getIntExtra("year", 0)
        val description = intent.getStringExtra("description")

        findViewById<TextView>(R.id.detailTitle).text = "Title: $title"
        findViewById<TextView>(R.id.detailDirector).text = "Director: $director"
        findViewById<TextView>(R.id.detailGenre).text = "Genre: $genre"
        findViewById<TextView>(R.id.detailYear).text = "Year: $year"
        findViewById<TextView>(R.id.detailDescription).text = "Description: $description"
    }
}
