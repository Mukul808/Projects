package com.example.dependency.network

import com.example.dependency.model.Movie
import com.example.dependency.model.MovieResponse

import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET("dashboard/movies")
    suspend fun getMovies(): Response<MovieResponse>
}
